package com.cergenerator.service;

import org.springframework.stereotype.Service;

import com.cergenerator.model.CertificateData;

@Service
public class CertificateService {

	public CertificateService() {
		// TODO Auto-generated constructor stub
	}
	
	public CertificateData newCertificate(CertificateData cerData){
		// TODO: Implement
		return null;
	}
}
