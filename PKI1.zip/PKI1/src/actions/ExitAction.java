package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

public class ExitAction extends AbstractAction {
	
	public ExitAction() {
		
		putValue(SHORT_DESCRIPTION, "Exit");
		putValue(NAME, "Exit");
	}

	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
