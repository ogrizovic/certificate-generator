package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

public class JarsAction extends AbstractAction {
	
	public JarsAction() {
		
		putValue(SHORT_DESCRIPTION, "JARs");
		putValue(NAME, "JARs");
	}

	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
